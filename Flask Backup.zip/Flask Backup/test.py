from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)


@app.route('/', methods=["GET", "POST"])
def home():
    file = open('Data.txt', 'r')
    text = file.read()
    return render_template('index.html', text=text)


@app.route('/page')
def page():
    return render_template('page1.html')


@app.route('/contact')
def contact():
    return render_template('contact.html')


@app.route('/api', methods=["GET", "POST"])
def api():
    if request.method == "GET":
        file = open('Data.txt', 'a')
        file.write(request.args.get('q'))
        file.close()
        return redirect(url_for('home'))

if __name__ == "__main__":
    app.run(port=80, debug=True)